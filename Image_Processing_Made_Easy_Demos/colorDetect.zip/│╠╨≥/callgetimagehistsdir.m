d='images2';
[Hists,files]=getimagehistsdir(d);