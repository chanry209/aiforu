echo on

mex corr2cov.c

mex cov2corr.c

mex dirichlet_mle.c

mex dirirnd.c

mex loglike_mvgm.c

mex mvgmmpdf.c

mex ndellipse.c

mex -DranSHR3 randnt.c

mex -DranSHR3 sample_mvgm.c


echo off